import {Component} from '@angular/core';

@Component({
  selector: 'app-shop-promotions',
  templateUrl: 'shop-promotions.component.html',
  styleUrls: ['shop-promotions.component.scss']
})
export class ShopPromotionsComponent {

}
