import {Component} from '@angular/core';

@Component({
    selector: 'app-shop-home',
    templateUrl: 'shop-home.component.html'
  }
)
export class ShopHomeComponent {


}
